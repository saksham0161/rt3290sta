#/bin/sh

modprobe -r rt2x00pci
