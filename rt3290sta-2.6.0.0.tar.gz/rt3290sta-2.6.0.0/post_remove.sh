#/bin/sh

rm /etc/modprobe.d/blacklist-ralink.conf
